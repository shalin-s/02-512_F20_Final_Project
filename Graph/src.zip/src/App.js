
import './App.css';
import React, { Component } from "react";
import Simulation from "./Simulation"


class App extends Component {
  componentDidMount() {
  }
  render() {
  return (<>
  <Simulation></Simulation>
    </>
);
}}


export default App;
