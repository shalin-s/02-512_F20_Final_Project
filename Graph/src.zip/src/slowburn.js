export const slowburn ={
    links:
[
  {
    source: "65",
    target: "21"
  },
  {
    source: "65",
    target: "14"
  },
  {
    source: "65",
    target: "14"
  },
  {
    source: "65",
    target: "20"
  },
  {
    source: "65",
    target: "20"
  },
  {
    source: "65",
    target: "21"
  },
  {
    source: "21",
    target: "14"
  },
  {
    source: "21",
    target: "24"
  },
  {
    source: "21",
    target: "54"
  },
  {
    source: "21",
    target: "18"
  },
  {
    source: "21",
    target: "41"
  },
  {
    source: "18",
    target: "20"
  },
  {
    source: "18",
    target: "54"
  },
  {
    source: "18",
    target: "41"
  },
  {
    source: "23",
    target: "18"
  },
  {
    source: "23",
    target: "41"
  },
  {
    source: "23",
    target: "54"
  },
  {
    source: "23",
    target: "14"
  },
  {
    source: "23",
    target: "25"
  },
  {
    source: "23",
    target: "46"
  },
  {
    source: "46",
    target: "24"
  },
  {
    source: "46",
    target: "41"
  },
  {
    source: "25",
    target: "22"
  },
  {
    source: "25",
    target: "16"
  },
  {
    source: "25",
    target: "E"
  },
  {
    source: "63",
    target: "22"
  },
  {
    source: "63",
    target: "E"
  },
  {
    source: "63",
    target: "16"
  },
  {
    source: "63",
    target: "46"
  },
  {
    source: "63",
    target: "24"
  },
  {
    source: "16",
    target: "14"
  },
  {
    source: "16",
    target: "20"
  },
  {
    source: "M",
    target: "63"
  },
  {
    source: "M",
    target: "22"
  },
  {
    source: "M",
    target: "16"
  },
  {
    source: "A",
    target: "M"
  },
  {
    source: "A",
    target: "M"
  },
  {
    source: "A",
    target: "E"
  },
  {
    source: "A",
    target: "16"
  },
  {
    source: "A",
    target: "55"
  },
  {
    source: "A",
    target: "L"
  },
  {
    source: "M",
    target: "L"
  },
  {
    source: "M",
    target: "55"
  },
  {
    source: "55",
    target: "19"
  },
  {
    source: "55",
    target: "L"
  },
  {
    source: "44",
    target: "L"
  },
  {
    source: "44",
    target: "55"
  },
  {
    source: "44",
    target: "19"
  },
  {
    source: "J",
    target: "44"
  },
  {
    source: "J",
    target: "19"
  },
  {
    source: "J",
    target: "83"
  },
  {
    source: "19",
    target: "83"
  },
  {
    source: "83",
    target: "89"
  },
  {
    source: "83",
    target: "D"
  },
  {
    source: "83",
    target: "D"
  },
  {
    source: "83",
    target: "J"
  },
  {
    source: "J",
    target: "D"
  },
  {
    source: "J",
    target: "89"
  },
  {
    source: "D",
    target: "89"
  },
  {
    source: "43",
    target: "D"
  },
  {
    source: "43",
    target: "89"
  },
  {
    source: "43",
    target: "G"
  },
  {
    source: "89",
    target: "G"
  },
  {
    source: "D",
    target: "G"
  },
  {
    source: "44",
    target: "83"
  },
  {
    source: "L",
    target: "19"
  },
  {
    source: "87",
    target: "96"
  },
  {
    source: "87",
    target: "93"
  },
  {
    source: "87",
    target: "85"
  },
  {
    source: "87",
    target: "85"
  },
  {
    source: "20",
    target: "85"
  },
  {
    source: "20",
    target: "93"
  },
  {
    source: "20",
    target: "87"
  },
  {
    source: "20",
    target: "87"
  },
  {
    source: "20",
    target: "96"
  },
  {
    source: "20",
    target: "96"
  },
  {
    source: "97",
    target: "20"
  },
  {
    source: "97",
    target: "18"
  },
  {
    source: "81",
    target: "97"
  },
  {
    source: "81",
    target: "87"
  },
  {
    source: "81",
    target: "93"
  },
  {
    source: "81",
    target: "93"
  },
  {
    source: "14",
    target: "85"
  },
  {
    source: "14",
    target: "92"
  },
  {
    source: "87",
    target: "90"
  },
  {
    source: "87",
    target: "91"
  },
  {
    source: "87",
    target: "91"
  },
  {
    source: "87",
    target: "82"
  },
  {
    source: "87",
    target: "98"
  },
  {
    source: "98",
    target: "92"
  },
  {
    source: "98",
    target: "85"
  },
  {
    source: "98",
    target: "93"
  },
  {
    source: "98",
    target: "96"
  },
  {
    source: "98",
    target: "82"
  },
  {
    source: "98",
    target: "91"
  },
  {
    source: "98",
    target: "90"
  },
  {
    source: "16",
    target: "92"
  },
  {
    source: "16",
    target: "98"
  },
  {
    source: "16",
    target: "85"
  },
  {
    source: "16",
    target: "85"
  },
  {
    source: "16",
    target: "93"
  },
  {
    source: "16",
    target: "96"
  },
  {
    source: "G",
    target: "57"
  },
  {
    source: "G",
    target: "60"
  },
  {
    source: "60",
    target: "43"
  },
  {
    source: "60",
    target: "57"
  },
  {
    source: "60",
    target: "42"
  },
  {
    source: "57",
    target: "42"
  },
  {
    source: "57",
    target: "48"
  },
  {
    source: "48",
    target: "60"
  },
  {
    source: "48",
    target: "42"
  },
  {
    source: "42",
    target: "58"
  },
  {
    source: "42",
    target: "H"
  },
  {
    source: "42",
    target: "K"
  },
  {
    source: "42",
    target: "C"
  },
  {
    source: "42",
    target: "95"
  },
  {
    source: "95",
    target: "99"
  },
  {
    source: "95",
    target: "94"
  },
  {
    source: "95",
    target: "94"
  },
  {
    source: "95",
    target: "95"
  },
  {
    source: "95",
    target: "86"
  },
  {
    source: "95",
    target: "C"
  },
  {
    source: "95",
    target: "K"
  },
  {
    source: "95",
    target: "H"
  },
  {
    source: "95",
    target: "58"
  },
  {
    source: "48",
    target: "79"
  },
  {
    source: "48",
    target: "36"
  },
  {
    source: "48",
    target: "64"
  },
  {
    source: "48",
    target: "59"
  },
  {
    source: "48",
    target: "47"
  },
  {
    source: "58",
    target: "47"
  },
  {
    source: "58",
    target: "59"
  },
  {
    source: "58",
    target: "N"
  },
  {
    source: "58",
    target: "64"
  },
  {
    source: "58",
    target: "48"
  },
  {
    source: "58",
    target: "36"
  },
  {
    source: "58",
    target: "36"
  },
  {
    source: "58",
    target: "79"
  },
  {
    source: "58",
    target: "42"
  },
  {
    source: "99",
    target: "C"
  },
  {
    source: "99",
    target: "K"
  },
  {
    source: "99",
    target: "42"
  },
  {
    source: "99",
    target: "47"
  },
  {
    source: "52",
    target: "36"
  },
  {
    source: "52",
    target: "79"
  },
  {
    source: "52",
    target: "48"
  },
  {
    source: "52",
    target: "64"
  },
  {
    source: "52",
    target: "N"
  },
  {
    source: "52",
    target: "59"
  },
  {
    source: "52",
    target: "47"
  },
  {
    source: "52",
    target: "80"
  },
  {
    source: "52",
    target: "66"
  },
  {
    source: "52",
    target: "69"
  },
  {
    source: "52",
    target: "75"
  },
  {
    source: "52",
    target: "78"
  },
  {
    source: "52",
    target: "73"
  },
  {
    source: "52",
    target: "74"
  },
  {
    source: "71",
    target: "48"
  },
  {
    source: "71",
    target: "79"
  },
  {
    source: "71",
    target: "36"
  },
  {
    source: "71",
    target: "78"
  },
  {
    source: "71",
    target: "75"
  },
  {
    source: "71",
    target: "69"
  },
  {
    source: "71",
    target: "66"
  },
  {
    source: "71",
    target: "52"
  },
  {
    source: "79",
    target: "84"
  },
  {
    source: "79",
    target: "72"
  },
  {
    source: "79",
    target: "77"
  },
  {
    source: "79",
    target: "67"
  },
  {
    source: "79",
    target: "34"
  },
  {
    source: "35",
    target: "34"
  },
  {
    source: "35",
    target: "67"
  },
  {
    source: "35",
    target: "77"
  },
  {
    source: "35",
    target: "77"
  },
  {
    source: "35",
    target: "72"
  },
  {
    source: "35",
    target: "71"
  },
  {
    source: "35",
    target: "70"
  },
  {
    source: "35",
    target: "76"
  },
  {
    source: "74",
    target: "73"
  },
  {
    source: "74",
    target: "70"
  },
  {
    source: "74",
    target: "78"
  },
  {
    source: "74",
    target: "67"
  },
  {
    source: "74",
    target: "34"
  },
  {
    source: "84",
    target: "45"
  },
  {
    source: "45",
    target: "I"
  },
  {
    source: "45",
    target: "56"
  },
  {
    source: "F",
    target: "45"
  },
  {
    source: "F",
    target: "84"
  },
  {
    source: "56",
    target: "I"
  },
  {
    source: "56",
    target: "I"
  },
  {
    source: "56",
    target: "F"
  },
  {
    source: "50",
    target: "84"
  },
  {
    source: "50",
    target: "71"
  },
  {
    source: "50",
    target: "56"
  },
  {
    source: "B",
    target: "62"
  },
  {
    source: "B",
    target: "88"
  },
  {
    source: "B",
    target: "61"
  },
  {
    source: "51",
    target: "49"
  },
  {
    source: "51",
    target: "61"
  },
  {
    source: "51",
    target: "88"
  },
  {
    source: "51",
    target: "39"
  },
  {
    source: "51",
    target: "62"
  },
  {
    source: "51",
    target: "38"
  },
  {
    source: "51",
    target: "40"
  },
  {
    source: "51",
    target: "I"
  },
  {
    source: "51",
    target: "F"
  },
  {
    source: "50",
    target: "53"
  },
  {
    source: "53",
    target: "F"
  },
  {
    source: "53",
    target: "40"
  },
  {
    source: "53",
    target: "38"
  },
  {
    source: "51",
    target: "30"
  },
  {
    source: "51",
    target: "17"
  },
  {
    source: "51",
    target: "15"
  },
  {
    source: "51",
    target: "31"
  },
  {
    source: "15",
    target: "28"
  },
  {
    source: "15",
    target: "32"
  },
  {
    source: "15",
    target: "33"
  },
  {
    source: "15",
    target: "29"
  },
  {
    source: "27",
    target: "27"
  },
  {
    source: "27",
    target: "33"
  },
  {
    source: "27",
    target: "32"
  },
  {
    source: "27",
    target: "28"
  },
  {
    source: "31",
    target: "15"
  },
  {
    source: "31",
    target: "30"
  },
  {
    source: "31",
    target: "26"
  },
  {
    source: "17",
    target: "26"
  },
  {
    source: "17",
    target: "30"
  },
  {
    source: "17",
    target: "28"
  },
  {
    source: "17",
    target: "15"
  },
  {
    source: "68",
    target: "68"
  },
  {
    source: "68",
    target: "32"
  },
  {
    source: "68",
    target: "32"
  },
  {
    source: "68",
    target: "29"
  },
  {
    source: "68",
    target: "28"
  }
],
nodes: [
  {
    id: "A",
    color: "DarkKhaki"
  },
  {
    id: "B",
    color: "DarkKhaki"
  },
  {
    id: "C",
    color: "DarkKhaki"
  },
  {
    id: "D",
    color: "DarkKhaki"
  },
  {
    id: "E",
    color: "DarkKhaki"
  },
  {
    id: "F",
    color: "DarkKhaki"
  },
  {
    id: "G",
    color: "DarkKhaki"
  },
  {
    id: "H",
    color: "DarkKhaki"
  },
  {
    id: "I",
    color: "DarkKhaki"
  },
  {
    id: "J",
    color: "DarkKhaki"
  },
  {
    id: "K",
    color: "DarkKhaki"
  },
  {
    id: "L",
    color: "DarkKhaki"
  },
  {
    id: "M",
    color: "DarkKhaki"
  },
  {
    id: "N",
    color: "DarkKhaki"
  },
  {
    id: "14",
    color: "DarkKhaki"
  },
  {
    id: "15",
    color: "DarkKhaki"
  },
  {
    id: "16",
    color: "DarkKhaki"
  },
  {
    id: "17",
    color: "DarkKhaki"
  },
  {
    id: "18",
    color: "DarkKhaki"
  },
  {
    id: "19",
    color: "DarkKhaki"
  },
  {
    id: "20",
    color: "DarkKhaki"
  },
  {
    id: "21",
    color: "DarkKhaki"
  },
  {
    id: "22",
    color: "DarkKhaki"
  },
  {
    id: "23",
    color: "DarkKhaki"
  },
  {
    id: "24",
    color: "DarkKhaki"
  },
  {
    id: "25",
    color: "DarkKhaki"
  },
  {
    id: "26",
    color: "DarkKhaki"
  },
  {
    id: "27",
    color: "DarkKhaki"
  },
  {
    id: "28",
    color: "DarkKhaki"
  },
  {
    id: "29",
    color: "DarkKhaki"
  },
  {
    id: "30",
    color: "DarkKhaki"
  },
  {
    id: "31",
    color: "DarkKhaki"
  },
  {
    id: "32",
    color: "DarkKhaki"
  },
  {
    id: "33",
    color: "DarkKhaki"
  },
  {
    id: "34",
    color: "DarkKhaki"
  },
  {
    id: "35",
    color: "DarkKhaki"
  },
  {
    id: "36",
    color: "DarkKhaki"
  },
  {
    id: "37",
    color: "DarkKhaki"
  },
  {
    id: "38",
    color: "DarkKhaki"
  },
  {
    id: "39",
    color: "DarkKhaki"
  },
  {
    id: "40",
    color: "DarkKhaki"
  },
  {
    id: "41",
    color: "DarkKhaki"
  },
  {
    id: "42",
    color: "DarkKhaki"
  },
  {
    id: "43",
    color: "DarkKhaki"
  },
  {
    id: "44",
    color: "DarkKhaki"
  },
  {
    id: "45",
    color: "DarkKhaki"
  },
  {
    id: "46",
    color: "DarkKhaki"
  },
  {
    id: "47",
    color: "DarkKhaki"
  },
  {
    id: "48",
    color: "DarkKhaki"
  },
  {
    id: "49",
    color: "DarkKhaki"
  },
  {
    id: "50",
    color: "DarkKhaki"
  },
  {
    id: "51",
    color: "DarkKhaki"
  },
  {
    id: "52",
    color: "DarkKhaki"
  },
  {
    id: "53",
    color: "DarkKhaki"
  },
  {
    id: "54",
    color: "DarkKhaki"
  },
  {
    id: "55",
    color: "DarkKhaki"
  },
  {
    id: "56",
    color: "DarkKhaki"
  },
  {
    id: "57",
    color: "DarkKhaki"
  },
  {
    id: "58",
    color: "DarkKhaki"
  },
  {
    id: "59",
    color: "DarkKhaki"
  },
  {
    id: "60",
    color: "DarkKhaki"
  },
  {
    id: "61",
    color: "DarkKhaki"
  },
  {
    id: "62",
    color: "DarkKhaki"
  },
  {
    id: "63",
    color: "DarkKhaki"
  },
  {
    id: "64",
    color: "DarkKhaki"
  },
  {
    id: "65",
    color: "LightCoral"
  },
  {
    id: "66",
    color: "DarkKhaki"
  },
  {
    id: "67",
    color: "DarkKhaki"
  },
  {
    id: "68",
    color: "DarkKhaki"
  },
  {
    id: "69",
    color: "DarkKhaki"
  },
  {
    id: "70",
    color: "DarkKhaki"
  },
  {
    id: "71",
    color: "DarkKhaki"
  },
  {
    id: "72",
    color: "DarkKhaki"
  },
  {
    id: "73",
    color: "DarkKhaki"
  },
  {
    id: "74",
    color: "DarkKhaki"
  },
  {
    id: "75",
    color: "DarkKhaki"
  },
  {
    id: "76",
    color: "DarkKhaki"
  },
  {
    id: "77",
    color: "DarkKhaki"
  },
  {
    id: "78",
    color: "DarkKhaki"
  },
  {
    id: "79",
    color: "DarkKhaki"
  },
  {
    id: "80",
    color: "DarkKhaki"
  },
  {
    id: "81",
    color: "DarkKhaki"
  },
  {
    id: "82",
    color: "DarkKhaki"
  },
  {
    id: "83",
    color: "DarkKhaki"
  },
  {
    id: "84",
    color: "DarkKhaki"
  },
  {
    id: "85",
    color: "DarkKhaki"
  },
  {
    id: "86",
    color: "DarkKhaki"
  },
  {
    id: "87",
    color: "DarkKhaki"
  },
  {
    id: "88",
    color: "DarkKhaki"
  },
  {
    id: "89",
    color: "DarkKhaki"
  },
  {
    id: "90",
    color: "DarkKhaki"
  },
  {
    id: "91",
    color: "DarkKhaki"
  },
  {
    id: "92",
    color: "DarkKhaki"
  },
  {
    id: "93",
    color: "DarkKhaki"
  },
  {
    id: "94",
    color: "DarkKhaki"
  },
  {
    id: "95",
    color: "DarkKhaki"
  },
  {
    id: "96",
    color: "DarkKhaki"
  },
  {
    id: "97",
    color: "DarkKhaki"
  },
  {
    id: "98",
    color: "DarkKhaki"
  },
  {
    id: "99",
    color: "DarkKhaki"
  }
]
}
export default slowburn;